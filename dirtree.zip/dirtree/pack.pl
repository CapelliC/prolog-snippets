name(dirtree).
title('directory XML structure').
version('1.0.0').
author('Capelli Carlo', 'cc.carlo.cap@gmail.com').
packager('Capelli Carlo', 'cc.carlo.cap@gmail.com').
provides('XML of directory').
requires(lambda).

