name(dirtree).
title('load XML of directory content').
version('1.0.0').
author('Carlo Capelli', 'cc.carlo.cap@gmail.com').

